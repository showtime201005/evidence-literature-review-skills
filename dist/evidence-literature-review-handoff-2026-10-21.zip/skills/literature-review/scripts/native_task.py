from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent/'runtime'))
from litreview_core.native_task import main

if __name__=='__main__':
    main()
