"""Portable skill entrypoint for the shared standard-library installer."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / 'runtime'))
from litreview_core.skill_installation import install, main


if __name__ == '__main__':
    raise SystemExit(main())
